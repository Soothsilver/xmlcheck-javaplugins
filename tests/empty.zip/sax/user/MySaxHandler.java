package user;

import org.xml.sax.helpers.DefaultHandler;
public class MySaxHandler extends DefaultHandler {
    // overrides of DefaultHandler methods
    // Do nothing.
}